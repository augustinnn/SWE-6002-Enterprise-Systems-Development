INSERT INTO user (name, specialization, password) VALUES ('Augustin', 'Internet', 'pass1');
INSERT INTO user (name, specialization, password) VALUES ('Brinza', 'Windows', 'pass2');
INSERT INTO user (name, specialization, password) VALUES ('Constantin', 'Macintosh', 'pass3');

/*
INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Mark', '07223344', 'mark@email.com', '1', '20.01.2024', 'slow internet speed', 'he had multiple devices using internet data', 'call back on 30.01.2024 when he get new router');
INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Ben', '07223345', 'ben@email.com', '1', '21.01.2024', 'reset internet password', 'he reset internet router and forgot paassword', 'no action required');
INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Yanna', '07223346', 'yanna@email.com', '1', '22.01.2024', 'install new router', 'he get new router', 'no action required');

INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Anthony', '07223354', 'anthony@email.com', '2', '19.01.2024', 'malware protection', 'he want a better malware protection', 'call back next month for feedback');
INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Steve', '07223364', 'steve@email.com', '2', '20.01.2024', 'windows activation', 'he want to purchase new windows for his laptop', 'no action required');
INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Jobs', '07223374', 'jobs@email.com', '2', '21.01.2024', 'drivers update', 'device working slow', 'no action required');

INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Claude', '07223347', 'claudde@email.com', '3', '18.01.2024', 'new usre', 'new user guide', 'send materials on email');
INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Harry', '07223348', 'harry@email.com', '3', '19.01.2024', 'new account', 'set up new account', 'no action requiredd');
INSERT INTO customer (name, telephone, email, employeeID, contactdate, contactreason, description, todo) VALUES ('Cristine', '07223349', 'cristine@email.com', '3', '20.01.2024', 'new user', 'new user guide', 'send materials on email');

INSERT INTO noncustomer (name, telephone, email, employeeID, contactdate, description, todo) VALUES ('Jerry', '07123347', 'jerry@email.com', '1', '15.01.2024', 'purchase another service', 'send newsletter');
INSERT INTO noncustomer (name, telephone, email, employeeID, contactdate, description, todo) VALUES ('Mike', '07123348', 'mike@email.com', '2', '14.01.2024', 'no description', 'send newsletter');
INSERT INTO noncustomer (name, telephone, email, employeeID, contactdate, description, todo) VALUES ('Dan', '07123349', 'ddan@email.com', '3', '16.01.2024', 'not satisfied with service', 'send newsletter');
*/



